PowerBuilder[R] Version 9 Read Me First 
*********************************************************************
Thank you for choosing PowerBuilder 9 as your development tool!

For last minute information, see the Release Bulletin included in 
the box with your software. You can read the latest version of the 
Release Bulletin on the Sybase Web site:

   1. Go to the PowerBuilder Documentation page at 
      http://sybooks.sybase.com/pb.html.
   2. Select "Release Bulletins."
   3. Select "PowerBuilder 9.0."
   4. Select the Release Bulletin for PowerBuilder Enterprise.
   
This product includes software developed by the Apache Software 
Foundation (http://www.apache.org/). For a copy of the Apache
Software License, see the APACHE_LICENSE.TXT file in the Support 
folder on the CD.

This product includes the EasySoap++ library in executable form in
EasySoap.dll, which is dynamically linked to PBsoapclient90.dll. The
EasySoap++ library and its use are covered by the GNU Lesser General
Public License (LGPL). For a copy of this license, see Gnu--LGPL.txt
in the Support folder on the CD. For additional information, see the
Release Bulletin.

**********************************************************************
(c) 1991-2003 Sybase, Inc. and its subsidiaries. All rights reserved. 
Sybase, Inc. and its subsidiaries ("Sybase") claim copyright in this 
program and documentation as an unpublished work, versions of which 
were first licensed on the date indicated in the foregoing notice. 
Claim of copyright does not imply waiver of Sybase's other rights. 
See Notice of Proprietary Rights.

NOTICE OF PROPRIETARY RIGHTS

This computer program and documentation are confidential trade 
secrets and the property of Sybase, Inc. and its subsidiaries. 
Use, examination, reproduction, copying, disassembly, decompilation, 
transfer and/or disclosure to others, in whole or in part, are 
strictly prohibited except with the express prior written consent of 
Sybase, Inc. and its subsidiaries.
