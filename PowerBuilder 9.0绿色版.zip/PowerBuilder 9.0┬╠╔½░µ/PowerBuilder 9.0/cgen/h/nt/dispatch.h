//+---------------------------------------------------------------------------
//
//  Microsoft Windows
//  Copyright (C) Microsoft Corporation, 1992-1996.
//
//  File:       dispatch.h
//
//----------------------------------------------------------------------------

#ifndef RC_INVOKED
#pragma message("WARNING: your code should #include oleauto.h instead of dispatch.h")
#endif /* !RC_INVOKED */

#include <oleauto.h>

