//+---------------------------------------------------------------------------
//
//  Microsoft Windows
//  Copyright (C) Microsoft Corporation, 1992-1996.
//
//  File:       dvobj.h
//
//----------------------------------------------------------------------------

#ifndef RC_INVOKED
#pragma message("WARNING: your code should include ole2.h instead of dvobj.h")
#endif /* !RC_INVOKED */

#include <ole2.h>

