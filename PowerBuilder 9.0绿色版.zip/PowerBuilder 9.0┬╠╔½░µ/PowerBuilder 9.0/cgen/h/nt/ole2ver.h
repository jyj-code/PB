/*****************************************************************************\
*                                                                             *
* ole2ver.h -   OLE 2 Version Number Info                                     *
*                                                                             *
*               Copyright (c) 1992-1996, Microsoft Corp. All rights reserved. *
*                                                                             *
\*****************************************************************************/

#ifndef _OLE2VER_H_
#define _OLE2VER_H_

#define rmm     23
#define rup     639

#endif
