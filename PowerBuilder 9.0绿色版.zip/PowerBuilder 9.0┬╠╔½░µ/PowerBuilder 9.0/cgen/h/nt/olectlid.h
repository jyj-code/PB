/*****************************************************************************\
*                                                                             *
* olectlid.h    Master definition of GUIDs for OLE Controls                   *
*                                                                             *
*               OLE Version 2.0                                               *
*                                                                             *
*               Copyright (c) 1992-1996, Microsoft Corp. All rights reserved. *
*                                                                             *
\*****************************************************************************/

#pragma message("WARNING: your code should #include olectl.h instead")
#include <olectl.h>
