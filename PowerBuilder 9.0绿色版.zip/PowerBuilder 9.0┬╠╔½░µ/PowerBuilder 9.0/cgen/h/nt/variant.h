//+---------------------------------------------------------------------------
//
//  Microsoft Windows
//  Copyright (C) Microsoft Corporation, 1992-1996.
//
//  File:       variant.h
//
//----------------------------------------------------------------------------

#ifndef RC_INVOKED
#pragma message("WARNING: your code should #include oleauto.h instead of variant.h")
#endif /* !RC_INVOKED */

#include <oleauto.h>

